const http = require('http')
const fs = require('fs')
const readline = require('readline');
const porta = 443

exports.startedServidor = function (){
const servidor = http.createServer((req, res) => {
  fs.readFile('pagina.html', (err, arquivo) => {
    res.writeHead(200, {'content-type' : 'text/html'})
    res.write(arquivo)
    res.end()})
})

servidor.listen(porta, () => {console.log('Servidor Rodando')})
}