const http = require('http');
const fs = require('fs');
const porta = 443;
const readline = require('readline');
const createTxt = require('./fileSystemTxt');
const servidorHTML = require('./servidorHTML');

servidorHTML.startedServidor();
createTxt.startedServerTXT();

async function readFileByLine(file) {
const fileStream = fs.createReadStream(file);
const rl = readline.createInterface({
input: fileStream,
crlfDelay: Infinity
});
for await (const line of rl) {
console.log('\n====================================');
console.log(line);
}
}

readFileByLine('teste.txt')


