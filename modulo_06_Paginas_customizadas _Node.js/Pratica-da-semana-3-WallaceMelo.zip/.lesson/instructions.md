Atividade Prática da 3ª semana (Repl.it)
Olá!

Nesta atividade você vai colocar em prática o conteúdo abordado na semana.

ESTA ATIVIDADE SERÁ DESENVOLVIDA NO REPL.IT E DEVERÁ SER POSTADA NESTA TAREFA EM ARQUIVO ZIP, CONFORME ORIENTAÇÕES ABAIXO:

Você deve criar um Servidor Web em Node que ofereça o serviço de envio de arquivos, com as seguintes funcionalidades:

Crie uma página principal (que será lida) em HTML com título e subtítulo. Apresente a opção de seleção e envio de arquivos.
Adicione CSS à página, mude a cor de fundo e a cor da fonte, pelo menos.
Faça a leitura desse arquivo (HTML).
Crie o serviço de envio (upload) de arquivos (fotos e documentos). 
Liste os arquivo(s) enviado(s) na pasta de upload do servidor (somente pasta "raiz"). Utilize a ajuda do código: (Codificação) - Listar arquivos da pasta).
A leitura do arquivo será exibida no console.
Siga o caminho abaixo:

Assista aos vídeos da semana.
Leia, em paralelo, os materiais das aulas da semana.
Acesse o Replit.
Realize a codificação da atividade (Prática da semana 3).
Salve o código no seu computador.
Compacte o arquivo.
Envie o arquivo aqui.
Se a atividade não estiver sendo mostrada para você, entre em contato com o monitor ou professor mediador o quanto antes. 

Valor: 10 pontos

Prazo final: 17/04/2023