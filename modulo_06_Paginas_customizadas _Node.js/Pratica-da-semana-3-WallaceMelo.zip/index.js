const http = require('http');
const porta = 443;
const formidavel = require('formidable');
const fs = require('fs');

 function listarArquivos(diretorio, arquivos) {
      if (!arquivos)
        arquivos = []
      let listagemArquivos = fs.readdirSync(diretorio)
      console.log(listagemArquivos)
    }

const servidor = http.createServer((req, res) => {
  if (req.url != '/enviodearquivo') {
    
    fs.readFile('pagina.html', (err, arquivo) => {
      res.writeHead(200, { 'content-type': 'text/html' })
      res.write(arquivo)
      return res.end()
    });
    
  } if (req.url == '/listar') {
    
  res.write('<h1>Arquivo(s) exibido(s) no console!</h1>'); 
  listarArquivos('./enviodearquivo');
  }
  else {
    
    const form = new formidavel.IncomingForm();
    form.parse(req, (erro, campos, arquivos) => {
      const urlAntiga = arquivos.filetoupload.filepath;
      const urlNova = './enviodearquivo/' + arquivos.filetoupload.originalFilename;
      var rawData = fs.readFileSync(urlAntiga);
      fs.writeFile(urlNova, rawData, function (err) {
        if (err) console.log(err);
        res.write("<h1>Arquivo enviado com sucesso!</h1>");
        res.end();
      })
    })
  }
});

servidor.listen(porta, () => { console.log('Servidor Rodando!') });

