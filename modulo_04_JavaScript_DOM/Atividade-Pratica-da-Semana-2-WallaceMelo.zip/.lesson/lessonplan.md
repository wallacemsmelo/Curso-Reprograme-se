## Grade de correção
![Grade](assets/F1-M4-Sem02-Praticas-Grade.png)